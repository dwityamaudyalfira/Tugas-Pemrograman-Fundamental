class Main {
  public static void main(String[] args) {
    // untuk menampilkan Salam Mahasiswa! sebanyak 2 baris
    System.out.println("Salam Mahasiswa!");
    System.out.println("Salam Mahasiswa!");
  }
}