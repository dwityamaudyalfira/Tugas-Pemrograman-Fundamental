import java.util.Scanner;
class Main {
    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);
        String nama = input.nextLine();
        System.out.println( "Hai " + nama );

    }
}