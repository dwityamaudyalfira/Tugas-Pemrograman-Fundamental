import java.util.Scanner;

class Main {
  public static void main(String[] args) {
    Scanner input = new Scanner(System.in);
    int angka = input.nextInt();
    
    for (int j = 1; j <= angka; j++) {
    System.out.println(j);
      }

        }
        
  }