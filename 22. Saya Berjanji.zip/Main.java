class Main {
  public static void main(String[] args) {
    
    for (int kalimat = 1; kalimat <= 20; kalimat++) {
            System.out.println("Saya berjanji akan rajin belajar Java!");
    }
  }
}