class Main {
  public static void main(String[] args) {
    // untuk menampilkan Salam Java
    System.out.println("Salam Java");
  }
}