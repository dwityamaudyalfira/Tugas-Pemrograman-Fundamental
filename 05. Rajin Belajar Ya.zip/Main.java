class Main {
  public static void main(String[] args) {
    char x = '\"';
    System.out.println("Saya berkata, " + x + "Rajin belajar, ya!" + x);
  }
}